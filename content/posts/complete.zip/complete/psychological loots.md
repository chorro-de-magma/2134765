# psychological loots
the iris shoots  
alien fruits  
at bubbly boots  
to help them ascend…  
_their roots_.  
psychological loots  
cut ties into suits   
bands sling tributes  
wrapped by denial   
to wring into a sap that's in style